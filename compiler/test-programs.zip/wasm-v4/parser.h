#include "AST.h"

// Main AST struct type recognition
struct AST *ast;

// Main function to run parser
int parser_main(FILE* inputfile);